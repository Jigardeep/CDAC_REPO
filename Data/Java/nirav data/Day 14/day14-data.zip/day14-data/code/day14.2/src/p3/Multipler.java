package p3;

public class Multipler implements Computable {

	@Override
	public double compute(double d1, double d2) {
		// TODO Auto-generated method stub
		return d1*d2;
	}

}
