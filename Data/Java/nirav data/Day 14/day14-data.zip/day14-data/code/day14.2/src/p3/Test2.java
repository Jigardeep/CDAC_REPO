package p3;

import java.util.List;

public class Test2 {
	public static void main(String[] args) {
		List<Integer> ints = List.of(1, 2, 4, 5, 34, 12, 1, 2, -10);
		//Can you print the elems in this list : using forEach
		ints.forEach(i -> System.out.println(i));
	}

	


}
