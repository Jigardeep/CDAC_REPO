package p1;

public class MyFormula implements Formula{

	@Override
	public double calculate(double a) {
		// TODO Auto-generated method stub
		return a*a;
	}
	//Can imple class inherit def method imple ? YES

}
