package custom_exceptions;

@SuppressWarnings("serial")
public class ProductHandlingException extends Exception {
	

	/**
	 * 
	 */
//	private static final long serialVersionUID = 1L;

	/**
	 * 
	 */
//	private static final long serialVersionUID = -7793345261258061379L;
	

	public ProductHandlingException(String message) {
		super(message);
	}

}
