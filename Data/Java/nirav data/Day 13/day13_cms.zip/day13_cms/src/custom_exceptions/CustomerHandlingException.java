package custom_exceptions;

public class CustomerHandlingException extends Exception {
	public CustomerHandlingException(String mesg) {
		super(mesg);
	}
}
